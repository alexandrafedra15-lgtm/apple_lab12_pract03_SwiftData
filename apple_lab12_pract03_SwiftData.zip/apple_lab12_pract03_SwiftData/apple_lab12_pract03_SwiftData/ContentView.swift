//
//  ContentView.swift
//  apple_lab12_pract03_SwiftData
//
//  Created by Jaime Gomez on 1/6/25.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Teacher.firstName) private var teachers: [Teacher]

    @State private var searchText: String = ""
    @State private var showingAddSheet: Bool = false
    @State private var selectedTeacher: Teacher? = nil

    private var filteredTeachers: [Teacher] {
        let query = searchText.trimmingCharacters(in: .whitespaces)
        guard !query.isEmpty else { return teachers }
        return teachers.filter { teacher in
            teacher.fullName.localizedCaseInsensitiveContains(query) ||
            teacher.firstName.localizedCaseInsensitiveContains(query) ||
            teacher.lastName.localizedCaseInsensitiveContains(query) ||
            teacher.specialty.localizedCaseInsensitiveContains(query) ||
            teacher.email.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(filteredTeachers) { teacher in
                    Button {
                        selectedTeacher = teacher
                    } label: {
                        TeacherRowView(teacher: teacher)
                    }
                    .buttonStyle(.plain)
                }
                .onDelete(perform: deleteTeachers)
            }
            .navigationTitle("Teachers")
            .searchable(text: $searchText, prompt: "Search teachers...")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingAddSheet = true
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showingAddSheet) {
                AddTeacherView()
            }
            .sheet(item: $selectedTeacher) { teacher in
                EditTeacherView(teacher: teacher)
            }
        }
    }

    private func deleteTeachers(offsets: IndexSet) {
        withAnimation {
            for index in offsets {
                let teacher = filteredTeachers[index]
                modelContext.delete(teacher)
            }
        }
    }
}

struct TeacherRowView: View {
    let teacher: Teacher

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(teacher.fullName)
                .font(.headline)
            Text(teacher.specialty)
                .font(.subheadline)
                .foregroundColor(.secondary)
            Text(teacher.email)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 2)
    }
}

#Preview {
    let config = ModelConfiguration(isStoredInMemoryOnly: true)
    let container = try! ModelContainer(for: Teacher.self, configurations: config)

    let t1 = Teacher(
        firstName: "Jaime",
        lastName: "Gomez",
        email: "jgomezm@tecsup.edu.pe",
        phone: "945784125",
        dateOfBirth: Date(),
        specialty: "Java Senior",
        hireDate: Date(),
        isActive: true
    )
    let t2 = Teacher(
        firstName: "Juan",
        lastName: "Leon",
        email: "jleon@tecsup.edu.pe",
        phone: "987654321",
        dateOfBirth: Date(),
        specialty: "IOS Developer",
        hireDate: Date(),
        isActive: true
    )
    container.mainContext.insert(t1)
    container.mainContext.insert(t2)

    return ContentView()
        .modelContainer(container)
}
