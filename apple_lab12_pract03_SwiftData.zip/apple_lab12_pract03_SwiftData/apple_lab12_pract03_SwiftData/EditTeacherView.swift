//
//  EditTeacherView.swift
//  apple_lab12_pract03_SwiftData
//

import SwiftUI
import SwiftData

struct EditTeacherView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss

    let teacher: Teacher

    @State private var firstName: String
    @State private var lastName: String
    @State private var email: String
    @State private var phone: String
    @State private var dateOfBirth: Date
    @State private var specialty: String
    @State private var hireDate: Date
    @State private var isActive: Bool

    init(teacher: Teacher) {
        self.teacher = teacher
        _firstName = State(initialValue: teacher.firstName)
        _lastName = State(initialValue: teacher.lastName)
        _email = State(initialValue: teacher.email)
        _phone = State(initialValue: teacher.phone)
        _dateOfBirth = State(initialValue: teacher.dateOfBirth)
        _specialty = State(initialValue: teacher.specialty)
        _hireDate = State(initialValue: teacher.hireDate)
        _isActive = State(initialValue: teacher.isActive)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("PERSONAL INFORMATION") {
                    TextField("First Name", text: $firstName)
                    TextField("Last Name", text: $lastName)
                    TextField("Email", text: $email)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("Phone", text: $phone)
                        .keyboardType(.phonePad)
                    DatePicker("Date of Birth", selection: $dateOfBirth, displayedComponents: .date)
                }

                Section("PROFESSIONAL INFORMATION") {
                    TextField("Specialty", text: $specialty)
                    DatePicker("Hire Date", selection: $hireDate, displayedComponents: .date)
                    Toggle("Active", isOn: $isActive)
                }

                Section {
                    Button(role: .destructive) {
                        modelContext.delete(teacher)
                        dismiss()
                    } label: {
                        Text("Delete Teacher")
                            .foregroundColor(.red)
                    }
                }
            }
            .navigationTitle("Edit Teacher")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        saveChanges()
                    }
                    .disabled(firstName.trimmingCharacters(in: .whitespaces).isEmpty || lastName.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }

    private func saveChanges() {
        teacher.firstName = firstName.trimmingCharacters(in: .whitespaces)
        teacher.lastName = lastName.trimmingCharacters(in: .whitespaces)
        teacher.email = email.trimmingCharacters(in: .whitespaces)
        teacher.phone = phone.trimmingCharacters(in: .whitespaces)
        teacher.dateOfBirth = dateOfBirth
        teacher.specialty = specialty.trimmingCharacters(in: .whitespaces)
        teacher.hireDate = hireDate
        teacher.isActive = isActive
        dismiss()
    }
}

#Preview {
    let sample = Teacher(
        firstName: "Jaime",
        lastName: "Gomez",
        email: "jgomezm@tecsup.edu.pe",
        phone: "945784125",
        dateOfBirth: Date(),
        specialty: "Java Senior",
        hireDate: Date(),
        isActive: true
    )
    EditTeacherView(teacher: sample)
        .modelContainer(for: Teacher.self, inMemory: true)
}
