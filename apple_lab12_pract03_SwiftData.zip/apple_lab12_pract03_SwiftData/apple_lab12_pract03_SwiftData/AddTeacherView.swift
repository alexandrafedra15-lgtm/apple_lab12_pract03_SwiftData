//
//  AddTeacherView.swift
//  apple_lab12_pract03_SwiftData
//

import SwiftUI
import SwiftData

struct AddTeacherView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss

    @State private var firstName: String = ""
    @State private var lastName: String = ""
    @State private var email: String = ""
    @State private var phone: String = ""
    @State private var dateOfBirth: Date = Date()
    @State private var specialty: String = ""
    @State private var hireDate: Date = Date()
    @State private var isActive: Bool = true

    var body: some View {
        NavigationStack {
            Form {
                Section("PERSONAL INFORMATION") {
                    TextField("First Name", text: $firstName)
                    TextField("Last Name", text: $lastName)
                    TextField("Email", text: $email)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("Phone", text: $phone)
                        .keyboardType(.phonePad)
                    DatePicker("Date of Birth", selection: $dateOfBirth, displayedComponents: .date)
                }

                Section("PROFESSIONAL INFORMATION") {
                    TextField("Specialty", text: $specialty)
                    DatePicker("Hire Date", selection: $hireDate, displayedComponents: .date)
                    Toggle("Active", isOn: $isActive)
                }
            }
            .navigationTitle("Add Teacher")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        saveTeacher()
                    }
                    .disabled(firstName.trimmingCharacters(in: .whitespaces).isEmpty || lastName.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }

    private func saveTeacher() {
        let newTeacher = Teacher(
            firstName: firstName.trimmingCharacters(in: .whitespaces),
            lastName: lastName.trimmingCharacters(in: .whitespaces),
            email: email.trimmingCharacters(in: .whitespaces),
            phone: phone.trimmingCharacters(in: .whitespaces),
            dateOfBirth: dateOfBirth,
            specialty: specialty.trimmingCharacters(in: .whitespaces),
            hireDate: hireDate,
            isActive: isActive
        )
        modelContext.insert(newTeacher)
        dismiss()
    }
}

#Preview {
    AddTeacherView()
        .modelContainer(for: Teacher.self, inMemory: true)
}
